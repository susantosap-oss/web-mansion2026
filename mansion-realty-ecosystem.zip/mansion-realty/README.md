# 🏛 Mansion Realty — Website Ekosistem Broker Properti

> **Stack:** Next.js 14 (App Router) + Tailwind CSS + Google Sheets (SSoT via GAS) + Google Cloud Run

---

## 📁 Struktur Proyek

```
mansion-realty/
├── src/
│   ├── app/
│   │   ├── page.tsx                    # Beranda (Home)
│   │   ├── layout.tsx                  # Root layout + Navbar/Footer
│   │   ├── globals.css                 # Global styles
│   │   ├── listings/
│   │   │   ├── page.tsx               # Daftar listing (Sale/Rent)
│   │   │   ├── titip/page.tsx         # Form titip listing
│   │   │   └── [slug]/page.tsx        # Detail listing + JSON-LD SEO
│   │   ├── projects/
│   │   │   ├── page.tsx               # Daftar proyek baru
│   │   │   └── [slug]/page.tsx        # Detail proyek
│   │   ├── calculator/page.tsx         # Kalkulator KPR (4 tab)
│   │   ├── agents/page.tsx             # Daftar agen
│   │   ├── agents/[id]/page.tsx        # Profil agen + listings
│   │   ├── news/                       # Berita & artikel
│   │   ├── admin/                      # Panel admin/webadmin
│   │   └── api/
│   │       ├── sheets/route.ts         # API bridge ke GAS
│   │       └── leads/route.ts          # CRUD data lead
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx             # Sticky navbar
│   │   │   └── Footer.tsx             # Footer dengan CTA
│   │   └── property/
│   │       └── PropertyCard.tsx        # Card listing & proyek
│   ├── lib/
│   │   ├── sheets.ts                   # Google Sheets API + caching
│   │   └── calculator.ts              # Logika KPR 4 jenis
│   └── types/index.ts                  # TypeScript types
├── gas/
│   └── api-bridge.gs                   # Google Apps Script (deploy sebagai Web App)
├── public/images/                       # Aset statis
├── tailwind.config.js                   # Config Tailwind + warna brand
├── next.config.js                       # Next.js config + ISR
├── Dockerfile                          # Multi-stage build untuk Cloud Run
├── cloudbuild.yaml                     # CI/CD Cloud Build
├── deploy.sh                           # Script deploy manual
└── .env.example                        # Template environment variables
```

---

## 🚀 Quick Start (Development)

```bash
# 1. Clone & install
git clone <repo>
cd mansion-realty
npm install

# 2. Setup env
cp .env.example .env.local
# Edit .env.local dengan nilai yang sesuai

# 3. Run development
npm run dev
# Buka http://localhost:3000
```

---

## 🔗 Setup Backend: Google Apps Script (API Bridge)

### Langkah 1: Siapkan Google Sheet CRM Mansion

Buat sheet dengan nama tab berikut (atau sesuaikan dengan SHEETS config di `gas/api-bridge.gs`):
- `DataProyek` — data proyek baru
- `DataListing` — listing dijual/disewa
- `DataAgen` — data agen kantor
- `DataBerita` — artikel/berita
- `DataLead` — lead dari website

Struktur kolom tersedia di bagian bawah file `gas/api-bridge.gs`.

### Langkah 2: Deploy Google Apps Script

1. Buka [script.google.com](https://script.google.com) → New Project
2. Copy-paste isi `gas/api-bridge.gs`
3. Ganti `SHEET_ID` dengan ID Google Sheet CRM Mansion Anda
4. Ganti `API_SECRET` dengan secret yang sama di `.env`
5. **Deploy** → **New Deployment** → **Web App**
   - Execute as: **Me**
   - Who has access: **Anyone**
6. Copy URL deployment → paste ke `NEXT_PUBLIC_GAS_API_URL` di `.env`

---

## 🗄️ Arsitektur Data & Caching

```
User Request
    ↓
Next.js Page (ISR revalidate: 300s)
    ↓
src/lib/sheets.ts (In-Memory Cache)
    ↓ Cache miss
Google Apps Script Web App (API Bridge)
    ↓
Google Sheets (CRM Mansion = SSoT)
```

- **ISR (Incremental Static Regeneration):** Halaman di-cache 5 menit
- **In-Memory Cache:** Server-side cache tambahan di `sheets.ts`
- **GAS Rate Limit:** Aman karena website hanya fetch ~1x per 5 menit

---

## 📊 Fitur Halaman

| Halaman | Route | SSR/ISR | SEO |
|---------|-------|---------|-----|
| Beranda | `/` | ISR 5m | ✅ |
| Daftar Listing | `/listings` | ISR 5m | ✅ |
| Detail Listing | `/listings/[slug]` | ISR 5m | ✅ JSON-LD |
| Daftar Proyek | `/projects` | ISR 5m | ✅ |
| Detail Proyek | `/projects/[slug]` | ISR 5m | ✅ JSON-LD |
| Kalkulator KPR | `/calculator` | Client | ✅ |
| Daftar Agen | `/agents` | ISR 10m | ✅ |
| Profil Agen | `/agents/[id]` | ISR 10m | ✅ |
| Berita | `/news` | ISR 10m | ✅ |
| Titip Listing | `/listings/titip` | Client | ✅ |

---

## ☁️ Deployment ke Google Cloud Run

### Opsi A: Manual via Cloud Shell

```bash
# 1. Buka Google Cloud Shell Console
# 2. Clone repo atau upload files
# 3. Edit deploy.sh: ganti PROJECT_ID, dan variabel lainnya
# 4. Jalankan:
chmod +x deploy.sh
./deploy.sh
```

### Opsi B: CI/CD via Cloud Build

1. Connect repo ke Cloud Source Repositories atau GitHub
2. Buat Cloud Build Trigger yang menunjuk ke `cloudbuild.yaml`
3. Set substitution variables di trigger configuration
4. Push ke `main` → auto-deploy!

### Custom Domain

```bash
gcloud run domain-mappings create \
  --service=mansion-realty-web \
  --domain=mansionrealty.co.id \
  --region=asia-southeast2
```

---

## 🎨 Branding & Design

- **Warna Primary:** `#0a2342` (Navy Dark) → tersedia sebagai `bg-primary-900`, `text-primary-900`, dll.
- **Warna Aksen:** `#c9a84c` (Gold) → `bg-gold`, `text-gold`, `btn-gold`
- **Font Display:** Playfair Display (serif) → `font-display`
- **Font Body:** DM Sans → `font-body`
- **Komponen:** Semua di `globals.css` sebagai custom class Tailwind

---

## 🔌 WhatsApp Integration

Setiap listing otomatis mengarahkan tombol WA ke **nomor agen pemilik listing**, bukan ke nomor kantor:

```typescript
// src/lib/sheets.ts
const waLink = buildWALink(listing.agentPhone, pesan)
```

Nomor kantor sebagai fallback: `NEXT_PUBLIC_WA_OFFICE` di `.env`

---

## 📱 Fitur yang Perlu Dikembangkan Selanjutnya

- [ ] Login agen (NextAuth.js + Google OAuth)
- [ ] Dashboard agen: Leads & Pipeline view
- [ ] Panel WebAdmin: input berita, logo, konten
- [ ] Profil agen `[id]/page.tsx` dengan listings agen tsb
- [ ] Detail proyek `[slug]/page.tsx`
- [ ] Search & filter advanced (kota, harga, luas)
- [ ] Sitemap.xml otomatis untuk SEO
- [ ] Google Analytics 4 integration
- [ ] Image upload ke Google Drive via GAS

---

## 📞 Support

Hubungi tim development via WhatsApp kantor atau buka issue di repository.
