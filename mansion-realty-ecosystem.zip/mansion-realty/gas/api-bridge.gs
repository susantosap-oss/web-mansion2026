/**
 * ============================================================
 * MANSION REALTY — Google Apps Script API Bridge
 * ============================================================
 * Deploy sebagai Web App:
 * 1. Buka script.google.com → New Project
 * 2. Paste kode ini
 * 3. Ganti SHEET_ID dengan ID Google Sheet CRM Mansion Anda
 * 4. Deploy → New Deployment → Web App
 *    - Execute as: Me
 *    - Who has access: Anyone (with API secret check)
 * 5. Copy URL deployment ke .env NEXT_PUBLIC_GAS_API_URL
 * ============================================================
 */

// ── CONFIG ────────────────────────────────────────────────
const SHEET_ID  = 'GANTI_DENGAN_ID_SPREADSHEET_CRM_MANSION'
const API_SECRET = 'GANTI_DENGAN_SECRET_YANG_SAMA_DI_ENV'

// ── Sheet Names (sesuaikan dengan nama sheet di CRM Mansion)
const SHEETS = {
  PROJECTS: 'DataProyek',
  LISTINGS: 'DataListing',
  AGENTS:   'DataAgen',
  NEWS:     'DataBerita',
  LEADS:    'DataLead',
}

// ── CORS & Auth ────────────────────────────────────────────
function addCORS(output) {
  return output
    .setMimeType(ContentService.MimeType.JSON)
    .setContent(output.getContent())
}

function validateSecret(secret) {
  return secret === API_SECRET
}

// ── Main Entry Point ───────────────────────────────────────
function doGet(e) {
  const action = e.parameter.action
  const secret = e.parameter.secret

  if (!validateSecret(secret)) {
    return response({ success: false, error: 'Unauthorized' })
  }

  try {
    switch (action) {
      case 'getProjects': return response({ success: true, data: getSheetData(SHEETS.PROJECTS) })
      case 'getListings': return response({ success: true, data: getSheetData(SHEETS.LISTINGS) })
      case 'getAgents':   return response({ success: true, data: getSheetData(SHEETS.AGENTS) })
      case 'getNews':     return response({ success: true, data: getSheetData(SHEETS.NEWS) })
      case 'getLeads': {
        const agentId = e.parameter.agentId
        const leads   = getSheetData(SHEETS.LEADS)
        const filtered = agentId ? leads.filter(r => r['Agent ID'] === agentId) : leads
        return response({ success: true, data: filtered })
      }
      default:
        return response({ success: false, error: `Unknown action: ${action}` })
    }
  } catch (err) {
    return response({ success: false, error: err.message })
  }
}

function doPost(e) {
  const secret = JSON.parse(e.postData.contents).secret || ''
  if (!validateSecret(secret)) {
    return response({ success: false, error: 'Unauthorized' })
  }

  const body   = JSON.parse(e.postData.contents)
  const action = e.parameter.action || body.action

  try {
    switch (action) {
      case 'saveLead': {
        saveLead(body)
        return response({ success: true, message: 'Lead saved' })
      }
      default:
        return response({ success: false, error: `Unknown POST action: ${action}` })
    }
  } catch (err) {
    return response({ success: false, error: err.message })
  }
}

// ── Helpers ────────────────────────────────────────────────
function getSheetData(sheetName) {
  const ss    = SpreadsheetApp.openById(SHEET_ID)
  const sheet = ss.getSheetByName(sheetName)
  if (!sheet) throw new Error(`Sheet "${sheetName}" tidak ditemukan`)

  const data    = sheet.getDataRange().getValues()
  const headers = data[0]
  const rows    = data.slice(1)

  return rows
    .filter(row => row.some(cell => cell !== '')) // skip empty rows
    .map(row => {
      const obj = {}
      headers.forEach((h, i) => { obj[h] = row[i] })
      return obj
    })
}

function saveLead(lead) {
  const ss    = SpreadsheetApp.openById(SHEET_ID)
  const sheet = ss.getSheetByName(SHEETS.LEADS)
  if (!sheet) throw new Error(`Sheet "${SHEETS.LEADS}" tidak ditemukan`)

  const now  = new Date().toISOString()
  const id   = 'LEAD-' + Date.now()

  sheet.appendRow([
    id,
    lead.listingId   || '',
    lead.listingTitle|| '',
    lead.agentId     || '',
    lead.name        || '',
    lead.phone       || '',
    lead.email       || '',
    lead.message     || '',
    lead.source      || 'Form',
    now,
    'New',
  ])

  // Optional: trigger email notification to agent
  // sendLeadNotification(lead)
}

function response(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON)
}

/**
 * ============================================================
 * STRUKTUR GOOGLE SHEET CRM MANSION
 * ============================================================
 *
 * Sheet: DataProyek
 * Kolom: ID | Slug | Nama Proyek | Developer | Lokasi | Kota | Provinsi |
 *         Harga Min | Harga Max | Tipe | Status | Deskripsi | Cover Image |
 *         Gambar | LT | LB | KT | KM | CP | Listrik | Air |
 *         Fasilitas | Agent ID | Created At | Updated At
 *
 * Sheet: DataListing
 * Kolom: ID | Slug | Judul | Tipe | Tipe Properti | Harga | Satuan Harga |
 *         Lokasi | Alamat | Kota | Provinsi | LT | LB | KT | KM | CP |
 *         Lantai | Kondisi | Sertifikat | Deskripsi | Cover Image | Gambar |
 *         Agent ID | Nama Agen | WA Agen | Foto Agen | Views | Leads |
 *         Status | Featured | Created At | Updated At
 *
 * Sheet: DataAgen
 * Kolom: ID | Nama | Foto | Telepon | Email | WhatsApp | Bio |
 *         Spesialisasi | Area | Total Listing | Total Deal | Rating |
 *         Verified | Join Date | Instagram | LinkedIn
 *
 * Sheet: DataBerita
 * Kolom: ID | Slug | Judul | Ringkasan | Konten | Cover Image |
 *         Kategori | Penulis | Tanggal | Tags | Views
 *
 * Sheet: DataLead
 * Kolom: ID | Listing ID | Judul Listing | Agent ID | Nama | Telepon |
 *         Email | Pesan | Source | Tanggal | Status
 * ============================================================
 */
