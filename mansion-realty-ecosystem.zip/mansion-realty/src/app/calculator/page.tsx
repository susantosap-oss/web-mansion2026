'use client'

import { useState, useCallback } from 'react'
import Link from 'next/link'
import { calculate, BANK_PRESETS } from '@/lib/calculator'
import { KPRParams, KPRResult } from '@/types'

type Tab = 'konvensional' | 'syariah' | 'kmg' | 'takeover'

const TABS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: 'konvensional', label: 'KPR Konvensional', icon: '🏦' },
  { id: 'syariah',      label: 'KPR Syariah',      icon: '☪️'  },
  { id: 'kmg',          label: 'KMG',              icon: '💰' },
  { id: 'takeover',     label: 'Take Over',        icon: '🔄' },
]

const DEFAULT_PARAMS: KPRParams = {
  hargaProperti: 800_000_000,
  uangMuka: 160_000_000,
  tenor: 20,
  bungaTahunan: 7.5,
  jenis: 'konvensional',
}

function formatRp(n: number): string {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n)
}

function InputRp({ label, value, onChange, helper }: {
  label: string; value: number; onChange: (v: number) => void; helper?: string
}) {
  const formatted = new Intl.NumberFormat('id-ID').format(value)
  return (
    <div>
      <label className="label-field">{label}</label>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-semibold">Rp</span>
        <input
          type="text"
          className="input-field pl-10"
          value={formatted}
          onChange={e => {
            const raw = e.target.value.replace(/\D/g, '')
            onChange(Number(raw))
          }}
        />
      </div>
      {helper && <p className="text-xs text-gray-400 mt-1">{helper}</p>}
    </div>
  )
}

export default function CalculatorPage() {
  const [tab,    setTab]    = useState<Tab>('konvensional')
  const [params, setParams] = useState<KPRParams>(DEFAULT_PARAMS)
  const [result, setResult] = useState<KPRResult | null>(null)
  const [showTable, setShowTable] = useState(false)

  const handleCalc = useCallback(() => {
    const res = calculate({ ...params, jenis: tab })
    setResult(res)
    setShowTable(false)
  }, [params, tab])

  const dp = Math.round((params.uangMuka / params.hargaProperti) * 100)
  const waOffice = process.env.NEXT_PUBLIC_WA_OFFICE || '6281234567890'

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="section-wrapper">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="divider-gold mx-auto mb-3" />
          <h1 className="section-title">Kalkulator KPR & Pembiayaan</h1>
          <p className="section-subtitle mx-auto">
            Simulasikan cicilan properti Anda dengan berbagai skema pembiayaan
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* ── LEFT: Form ── */}
          <div className="lg:col-span-2 space-y-6">

            {/* Tabs */}
            <div className="bg-white rounded-2xl p-2 shadow-card grid grid-cols-2 gap-1">
              {TABS.map(t => (
                <button
                  key={t.id}
                  onClick={() => { setTab(t.id); setResult(null) }}
                  className={`py-3 px-3 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-1.5 ${
                    tab === t.id
                      ? 'bg-primary-900 text-white shadow-navy'
                      : 'text-gray-500 hover:text-primary-900 hover:bg-gray-50'
                  }`}
                >
                  <span>{t.icon}</span>
                  <span className="text-xs">{t.label}</span>
                </button>
              ))}
            </div>

            {/* Inputs */}
            <div className="bg-white rounded-2xl p-6 shadow-card space-y-5">
              <InputRp
                label="Harga Properti"
                value={params.hargaProperti}
                onChange={v => setParams(p => ({ ...p, hargaProperti: v }))}
              />
              <InputRp
                label={`Uang Muka (DP) — ${dp}%`}
                value={params.uangMuka}
                onChange={v => setParams(p => ({ ...p, uangMuka: v }))}
                helper="Minimal 10-30% dari harga properti"
              />

              {/* Tenor */}
              <div>
                <label className="label-field">Tenor: <strong>{params.tenor} tahun</strong></label>
                <input
                  type="range" min={1} max={30} step={1} value={params.tenor}
                  onChange={e => setParams(p => ({ ...p, tenor: Number(e.target.value) }))}
                  className="w-full accent-primary-900"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>1 tahun</span><span>30 tahun</span>
                </div>
              </div>

              {/* Bunga */}
              <div>
                <label className="label-field">
                  {tab === 'syariah' ? 'Margin' : 'Bunga'} Tahunan: <strong>{params.bungaTahunan}%</strong>
                </label>
                <input
                  type="range" min={1} max={15} step={0.25} value={params.bungaTahunan}
                  onChange={e => setParams(p => ({ ...p, bungaTahunan: Number(e.target.value) }))}
                  className="w-full accent-primary-900"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>1%</span><span>15%</span>
                </div>
              </div>

              {/* Bank Presets */}
              <div>
                <label className="label-field">Pilih Acuan Bank</label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {BANK_PRESETS.filter(b =>
                    tab === 'syariah' ? b.type === 'syariah' : b.type === 'konvensional'
                  ).map(b => (
                    <button key={b.bank}
                      onClick={() => setParams(p => ({ ...p, bungaTahunan: b.rate, tenor: Math.min(p.tenor, b.maxTenor) }))}
                      className="text-left p-2 rounded-lg border border-gray-100 hover:border-primary-300 hover:bg-primary-50
                                 transition-colors text-xs">
                      <div className="font-bold text-primary-900">{b.bank}</div>
                      <div className="text-gray-500">{b.rate}% / {b.maxTenor}th</div>
                    </button>
                  ))}
                </div>
              </div>

              <button onClick={handleCalc} className="btn-primary w-full justify-center py-4 text-base">
                🧮 Hitung Simulasi
              </button>
            </div>
          </div>

          {/* ── RIGHT: Results ── */}
          <div className="lg:col-span-3 space-y-6">

            {result ? (
              <>
                {/* Summary Cards */}
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'Angsuran / Bulan', value: formatRp(result.totalAngsuran), highlight: true },
                    { label: 'Pokok Pinjaman',   value: formatRp(result.pokokPinjaman) },
                    { label: 'Total Pembayaran', value: formatRp(result.totalPembayaran) },
                    { label: 'Total Bunga/Margin',value: formatRp(result.totalBunga) },
                  ].map(item => (
                    <div key={item.label}
                      className={`rounded-2xl p-5 ${item.highlight ? 'bg-primary-900 text-white shadow-navy' : 'bg-white shadow-card'}`}>
                      <p className={`text-xs font-semibold mb-1 ${item.highlight ? 'text-white/70' : 'text-gray-400'}`}>
                        {item.label}
                      </p>
                      <p className={`text-xl font-display font-bold ${item.highlight ? 'text-gold' : 'text-primary-900'}`}>
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Breakdown toggle */}
                <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                  <div className="p-5 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-display font-bold text-primary-900">Tabel Amortisasi</h3>
                    <button onClick={() => setShowTable(v => !v)} className="text-sm text-primary-700 font-semibold">
                      {showTable ? '▲ Sembunyikan' : '▼ Lihat Tabel'}
                    </button>
                  </div>

                  {showTable && (
                    <div className="overflow-x-auto max-h-80 overflow-y-auto">
                      <table className="w-full text-xs">
                        <thead className="bg-primary-900 text-white sticky top-0">
                          <tr>
                            <th className="px-3 py-2 text-left">Bulan</th>
                            <th className="px-3 py-2 text-right">Angsuran</th>
                            <th className="px-3 py-2 text-right">Pokok</th>
                            <th className="px-3 py-2 text-right">Bunga</th>
                            <th className="px-3 py-2 text-right">Sisa Pokok</th>
                          </tr>
                        </thead>
                        <tbody>
                          {result.breakdown.map((row, i) => (
                            <tr key={row.bulan} className={i % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                              <td className="px-3 py-1.5 font-semibold text-gray-500">{row.bulan}</td>
                              <td className="px-3 py-1.5 text-right text-primary-900 font-semibold">{formatRp(row.angsuran)}</td>
                              <td className="px-3 py-1.5 text-right text-emerald-700">{formatRp(row.pokok)}</td>
                              <td className="px-3 py-1.5 text-right text-red-500">{formatRp(row.bunga)}</td>
                              <td className="px-3 py-1.5 text-right text-gray-600">{formatRp(row.sisaPokok)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* CTA */}
                <div className="bg-gold/10 border border-gold/30 rounded-2xl p-5">
                  <p className="font-display font-bold text-primary-900 mb-2">Butuh konsultasi pembiayaan?</p>
                  <p className="text-sm text-gray-600 mb-4">
                    Tim agen kami siap membantu proses pengajuan KPR Anda dari awal hingga akad.
                  </p>
                  <a href={`https://wa.me/${waOffice}?text=Halo%20Mansion%20Realty%2C%20saya%20butuh%20konsultasi%20KPR`}
                     target="_blank" rel="noopener noreferrer" className="btn-wa">
                    💬 Konsultasi KPR Gratis
                  </a>
                </div>
              </>
            ) : (
              /* Placeholder */
              <div className="bg-white rounded-2xl shadow-card p-12 text-center">
                <div className="text-6xl mb-4">🏦</div>
                <h3 className="font-display font-bold text-primary-900 text-xl mb-2">Simulasikan Cicilan Anda</h3>
                <p className="text-gray-500 font-body">
                  Masukkan harga properti dan parameter lainnya, lalu klik <strong>Hitung Simulasi</strong>.
                </p>
              </div>
            )}

            {/* Education section */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <h3 className="font-display font-bold text-primary-900 mb-4">Tentang Skema Pembiayaan</h3>
              <div className="space-y-4 text-sm text-gray-600 font-body">
                {tab === 'konvensional' && (
                  <div>
                    <h4 className="font-semibold text-primary-900 mb-1">📌 KPR Konvensional</h4>
                    <p>KPR konvensional menggunakan sistem bunga anuitas, di mana angsuran tetap setiap bulan namun komposisi pokok dan bunga berubah. Di awal masa kredit, porsi bunga lebih besar dibanding pokok pinjaman.</p>
                    <p className="mt-2">Keuntungan: Angsuran tetap, mudah direncanakan. Banyak pilihan bank dengan bunga kompetitif mulai 7-9% p.a.</p>
                  </div>
                )}
                {tab === 'syariah' && (
                  <div>
                    <h4 className="font-semibold text-primary-900 mb-1">📌 KPR Syariah (Murabahah)</h4>
                    <p>KPR Syariah menggunakan akad Murabahah di mana bank membeli properti lalu menjualnya kepada nasabah dengan harga yang sudah disepakati (termasuk margin keuntungan). Tidak ada bunga, bebas riba.</p>
                    <p className="mt-2">Margin biasanya 8-10% flat per tahun. Angsuran tetap dan tidak berubah selama tenor berjalan.</p>
                  </div>
                )}
                {tab === 'kmg' && (
                  <div>
                    <h4 className="font-semibold text-primary-900 mb-1">📌 KMG (Kredit Multiguna)</h4>
                    <p>KMG menggunakan properti sebagai agunan untuk mendapatkan dana tunai. Berbeda dengan KPR yang tujuannya membeli properti, KMG bertujuan untuk kebutuhan konsumtif atau modal usaha.</p>
                    <p className="mt-2">Plafon hingga 70% dari nilai properti. Bunga biasanya 1-2% lebih tinggi dari KPR biasa.</p>
                  </div>
                )}
                {tab === 'takeover' && (
                  <div>
                    <h4 className="font-semibold text-primary-900 mb-1">📌 Take Over KPR</h4>
                    <p>Take over KPR adalah proses pemindahan kredit dari satu bank ke bank lain, biasanya untuk mendapatkan bunga yang lebih rendah atau tenor yang lebih ringan.</p>
                    <p className="mt-2">Cocok untuk yang memiliki KPR dengan bunga tinggi dan ingin mendapatkan cicilan lebih rendah.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
