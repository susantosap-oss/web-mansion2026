import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { getProjects, getListings, getNews, formatPrice } from '@/lib/sheets'
import { ProjectCard } from '@/components/property/PropertyCard'
import { ListingCard } from '@/components/property/PropertyCard'

export const revalidate = 300 // ISR: revalidate every 5 minutes

export const metadata: Metadata = {
  title: 'Mansion Realty | Properti Impian Anda, Investasi Terbaik Anda',
  description: 'Temukan proyek perumahan, rumah dijual, dan properti premium bersama agen terpercaya Mansion Realty.',
}

export default async function HomePage() {
  const [projects, saleListings, rentListings, news] = await Promise.all([
    getProjects(),
    getListings({ type: 'Sale' }),
    getListings({ type: 'Rent' }),
    getNews(3),
  ])

  const featuredProjects  = projects.filter(p => p.status === 'Aktif').slice(0, 6)
  const featuredSale      = saleListings.slice(0, 6)
  const featuredRent      = rentListings.slice(0, 3)
  const waOffice = process.env.NEXT_PUBLIC_WA_OFFICE || '6281234567890'

  return (
    <>
      {/* ── Hero ───────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center bg-navy-texture overflow-hidden pt-20">
        {/* Background pattern */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-primary-950 via-primary-900 to-primary-800" />
          <div className="absolute right-0 top-0 w-1/2 h-full opacity-10"
            style={{ backgroundImage: 'repeating-linear-gradient(45deg,#c9a84c 0,#c9a84c 1px,transparent 0,transparent 50%)', backgroundSize: '20px 20px' }} />
        </div>

        <div className="section-wrapper relative z-10 py-20">
          <div className="max-w-3xl">
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-6 animate-fade-in-up">
              <div className="divider-gold" />
              <span className="text-gold font-body font-semibold text-sm uppercase tracking-widest">
                Agen Properti Terpercaya
              </span>
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold text-white leading-tight mb-6
                           animate-fade-in-up animate-delay-100">
              Properti Impian{' '}
              <span className="text-gradient-gold">Anda</span>,<br />
              Investasi Terbaik
            </h1>

            <p className="text-xl text-white/70 font-body mb-10 max-w-xl leading-relaxed
                          animate-fade-in-up animate-delay-200">
              Temukan rumah, apartemen, kavling, dan properti komersial premium dengan
              bantuan agen berpengalaman Mansion Realty.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4 animate-fade-in-up animate-delay-300">
              <Link href="/listings" className="btn-gold px-8 py-4 text-base">
                🏠 Cari Properti
              </Link>
              <a href={`https://wa.me/${waOffice}?text=Halo%20Mansion%20Realty%2C%20saya%20ingin%20konsultasi`}
                 target="_blank" rel="noopener noreferrer" className="btn-outline border-white text-white hover:bg-white hover:text-primary-900 px-8 py-4 text-base">
                💬 Konsultasi Gratis
              </a>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 mt-14 animate-fade-in-up animate-delay-400">
              {[
                { num: `${projects.length}+`,       label: 'Proyek Aktif' },
                { num: `${saleListings.length}+`,   label: 'Listing Dijual' },
                { num: '50+',                        label: 'Agen Berpengalaman' },
                { num: '1.000+',                     label: 'Transaksi Sukses' },
              ].map(stat => (
                <div key={stat.label}>
                  <div className="text-3xl font-display font-bold text-gold">{stat.num}</div>
                  <div className="text-sm text-white/60 font-body mt-0.5">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-white/40 text-xs font-body">Scroll</span>
          <svg className="w-5 h-5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </section>

      {/* ── Proyek Baru ─────────────────────────────────────── */}
      <section className="py-20 bg-white">
        <div className="section-wrapper">
          <div className="flex items-end justify-between mb-10">
            <div>
              <div className="divider-gold mb-3" />
              <h2 className="section-title">Proyek Baru</h2>
              <p className="section-subtitle">
                Perumahan dan apartemen baru dari developer terpercaya
              </p>
            </div>
            <Link href="/projects" className="hidden md:inline-flex btn-outline text-sm">
              Lihat Semua →
            </Link>
          </div>

          {featuredProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          ) : (
            <EmptyState message="Belum ada proyek baru saat ini." />
          )}

          <div className="mt-8 text-center md:hidden">
            <Link href="/projects" className="btn-outline">Lihat Semua Proyek</Link>
          </div>
        </div>
      </section>

      {/* ── Properti Dijual ──────────────────────────────────── */}
      <section className="py-20 bg-gray-50">
        <div className="section-wrapper">
          <div className="flex items-end justify-between mb-10">
            <div>
              <div className="divider-gold mb-3" />
              <h2 className="section-title">Properti Dijual</h2>
              <p className="section-subtitle">Pilihan properti terbaik siap dihuni dan diinvestasikan</p>
            </div>
            <Link href="/listings?type=Sale" className="hidden md:inline-flex btn-outline text-sm">
              Lihat Semua →
            </Link>
          </div>

          {featuredSale.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredSale.map(l => <ListingCard key={l.id} listing={l} />)}
            </div>
          ) : (
            <EmptyState message="Belum ada listing dijual." />
          )}
        </div>
      </section>

      {/* ── Properti Disewa ──────────────────────────────────── */}
      {featuredRent.length > 0 && (
        <section className="py-20 bg-white">
          <div className="section-wrapper">
            <div className="flex items-end justify-between mb-10">
              <div>
                <div className="divider-gold mb-3" />
                <h2 className="section-title">Properti Disewa</h2>
                <p className="section-subtitle">Hunian sewa bulanan dan tahunan strategis</p>
              </div>
              <Link href="/listings?type=Rent" className="hidden md:inline-flex btn-outline text-sm">
                Lihat Semua →
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredRent.map(l => <ListingCard key={l.id} listing={l} />)}
            </div>
          </div>
        </section>
      )}

      {/* ── Titip Listing CTA ─────────────────────────────────── */}
      <section className="py-20 bg-primary-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage: 'repeating-linear-gradient(45deg,#c9a84c 0,#c9a84c 1px,transparent 0,transparent 50%)', backgroundSize: '24px 24px' }} />

        <div className="section-wrapper relative z-10 text-center">
          <div className="divider-gold mx-auto mb-4" />
          <h2 className="section-title text-white mb-4">Punya Properti untuk Dijual atau Disewakan?</h2>
          <p className="text-white/70 font-body text-lg mb-8 max-w-2xl mx-auto">
            Titipkan listing properti Anda kepada agen profesional Mansion Realty.
            Gratis, mudah, dan cepat terjual.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/listings/titip" className="btn-gold px-8 py-4">
              📋 Titip Listing Sekarang
            </Link>
            <a href={`https://wa.me/${waOffice}?text=Halo%20Mansion%20Realty%2C%20saya%20ingin%20titip%20listing`}
               target="_blank" rel="noopener noreferrer" className="btn-wa px-8 py-4">
              💬 Chat via WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* ── KPR CTA ──────────────────────────────────────────── */}
      <section className="py-20 bg-cream">
        <div className="section-wrapper">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="divider-gold mb-4" />
              <h2 className="section-title mb-4">Rencanakan Pembiayaan Properti Anda</h2>
              <p className="text-gray-600 font-body mb-6 leading-relaxed">
                Gunakan kalkulator KPR kami untuk menghitung cicilan konvensional, syariah,
                KMG, dan take over secara akurat. Dapatkan simulasi lengkap dalam hitungan detik.
              </p>
              <Link href="/calculator" className="btn-primary">
                🧮 Hitung Simulasi KPR
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: '🏦', label: 'KPR Konvensional', desc: 'Angsuran anuitas bank umum' },
                { icon: '☪️', label: 'KPR Syariah',      desc: 'Akad murabahah bebas riba' },
                { icon: '💰', label: 'KMG',              desc: 'Kredit multiguna properti' },
                { icon: '🔄', label: 'Take Over',        desc: 'Alihkan KPR lebih ringan' },
              ].map(item => (
                <Link key={item.label} href="/calculator"
                  className="p-4 bg-white rounded-xl shadow-card hover:shadow-card-hover
                             transition-all duration-200 hover:-translate-y-1">
                  <div className="text-2xl mb-2">{item.icon}</div>
                  <div className="font-display font-semibold text-primary-900 text-sm">{item.label}</div>
                  <div className="text-xs text-gray-500 mt-1">{item.desc}</div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Berita ───────────────────────────────────────────── */}
      {news.length > 0 && (
        <section className="py-20 bg-white">
          <div className="section-wrapper">
            <div className="flex items-end justify-between mb-10">
              <div>
                <div className="divider-gold mb-3" />
                <h2 className="section-title">Berita & Artikel Properti</h2>
                <p className="section-subtitle">Update terkini seputar pasar properti Indonesia</p>
              </div>
              <Link href="/news" className="hidden md:inline-flex btn-outline text-sm">Lihat Semua →</Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {news.map((article, i) => (
                <Link key={article.id} href={`/news/${article.slug}`}
                  className={`card hover:shadow-card-hover transition-all duration-300 ${i === 0 ? 'md:col-span-1 row-span-2' : ''}`}>
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={article.coverImage || '/images/placeholder-news.jpg'}
                      alt={article.title}
                      fill className="object-cover property-image"
                    />
                    <span className="absolute top-3 left-3 badge bg-primary-900 text-white text-xs">
                      {article.category}
                    </span>
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-gray-400 mb-2">
                      {new Date(article.publishedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                    <h3 className="font-display font-semibold text-primary-900 line-clamp-2 hover:text-primary-700 transition-colors">
                      {article.title}
                    </h3>
                    <p className="text-sm text-gray-500 mt-2 line-clamp-2">{article.summary}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="text-center py-16 text-gray-400">
      <div className="text-5xl mb-4">🏠</div>
      <p className="font-body">{message}</p>
    </div>
  )
}
