import { NextResponse } from 'next/server'
import { Lead } from '@/types'

export async function POST(request: Request) {
  try {
    const body: Lead = await request.json()

    // Validation
    if (!body.listingId || !body.name || !body.phone) {
      return NextResponse.json(
        { success: false, error: 'listingId, name, dan phone wajib diisi' },
        { status: 400 }
      )
    }

    const payload = {
      ...body,
      createdAt: new Date().toISOString(),
      status: 'New',
    }

    // Send to Google Apps Script
    const GAS_URL    = process.env.NEXT_PUBLIC_GAS_API_URL!
    const GAS_SECRET = process.env.GAS_API_SECRET || ''

    const url = new URL(GAS_URL)
    url.searchParams.set('action', 'saveLead')
    url.searchParams.set('secret', GAS_SECRET)

    const res = await fetch(url.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })

    const json = await res.json()
    if (!json.success) {
      throw new Error(json.error || 'GAS save failed')
    }

    return NextResponse.json({ success: true, data: payload })
  } catch (err) {
    console.error('Lead save error:', err)
    return NextResponse.json(
      { success: false, error: 'Gagal menyimpan lead' },
      { status: 500 }
    )
  }
}

// GET - untuk agen melihat leads mereka (butuh auth)
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const agentId = searchParams.get('agentId')

  if (!agentId) {
    return NextResponse.json({ success: false, error: 'agentId required' }, { status: 400 })
  }

  // TODO: Validasi JWT token agen
  const GAS_URL    = process.env.NEXT_PUBLIC_GAS_API_URL!
  const GAS_SECRET = process.env.GAS_API_SECRET || ''

  const url = new URL(GAS_URL)
  url.searchParams.set('action', 'getLeads')
  url.searchParams.set('agentId', agentId)
  url.searchParams.set('secret', GAS_SECRET)

  const res  = await fetch(url.toString())
  const json = await res.json()

  return NextResponse.json(json)
}
