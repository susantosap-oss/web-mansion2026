import { NextResponse } from 'next/server'

// ── API Route: GET /api/sheets?action=getListings ─────────
// Ini adalah passthrough jika website ingin fetch langsung,
// atau bisa dipakai sebagai internal cache layer

export const dynamic    = 'force-dynamic'
export const revalidate = 0

const GAS_URL    = process.env.NEXT_PUBLIC_GAS_API_URL!
const GAS_SECRET = process.env.GAS_API_SECRET || ''

// In-memory cache
const cache = new Map<string, { data: unknown; expiresAt: number }>()

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const action = searchParams.get('action')

  if (!action) {
    return NextResponse.json({ success: false, error: 'action is required' }, { status: 400 })
  }

  const cacheKey   = `api:${action}`
  const ttlSeconds = 300
  const cached     = cache.get(cacheKey)

  if (cached && Date.now() < cached.expiresAt) {
    return NextResponse.json({
      success: true,
      data: cached.data,
      cached: true,
      timestamp: new Date().toISOString(),
    })
  }

  try {
    const url = new URL(GAS_URL)
    url.searchParams.set('action', action)
    url.searchParams.set('secret', GAS_SECRET)

    const res  = await fetch(url.toString(), { cache: 'no-store' })
    const json = await res.json()

    if (!json.success) {
      return NextResponse.json({ success: false, error: json.error }, { status: 502 })
    }

    cache.set(cacheKey, { data: json.data, expiresAt: Date.now() + ttlSeconds * 1000 })

    return NextResponse.json({
      success: true,
      data: json.data,
      cached: false,
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch from GAS', timestamp: new Date().toISOString() },
      { status: 500 }
    )
  }
}
