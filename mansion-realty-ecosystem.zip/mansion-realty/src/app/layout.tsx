import type { Metadata } from 'next'
import { Playfair_Display, DM_Sans, JetBrains_Mono } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://mansionrealty.co.id'),
  title: {
    default: 'Mansion Realty | Properti Impian Anda, Investasi Terbaik Anda',
    template: '%s | Mansion Realty',
  },
  description: 'Temukan properti impian Anda bersama Mansion Realty. Rumah, apartemen, kavling, dan properti komersial terbaik di seluruh Indonesia.',
  keywords: ['properti', 'rumah dijual', 'apartemen', 'kavling', 'broker properti', 'agen properti', 'KPR'],
  openGraph: {
    type: 'website',
    locale: 'id_ID',
    siteName: 'Mansion Realty',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className={`${playfair.variable} ${dmSans.variable} ${jetbrains.variable}`}>
      <body className="font-body bg-white text-gray-900 antialiased">
        <Navbar />
        <main className="min-h-screen">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
