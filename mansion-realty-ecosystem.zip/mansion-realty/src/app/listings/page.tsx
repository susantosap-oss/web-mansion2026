import type { Metadata } from 'next'
import Link from 'next/link'
import { getListings } from '@/lib/sheets'
import { ListingCard } from '@/components/property/PropertyCard'

export const revalidate = 300

export const metadata: Metadata = {
  title: 'Daftar Properti Dijual & Disewa | Mansion Realty',
  description: 'Temukan properti dijual dan disewa terbaik di seluruh Indonesia. Rumah, apartemen, kavling, ruko, dan properti komersial.',
}

interface SearchParams { type?: string; propertyType?: string; city?: string; search?: string }

export default async function ListingsPage({ searchParams }: { searchParams: SearchParams }) {
  const { type, propertyType, city } = searchParams

  const listings = await getListings({
    type: (type as 'Sale' | 'Rent') || undefined,
    propertyType,
    city,
  })

  const title = type === 'Sale' ? 'Properti Dijual' : type === 'Rent' ? 'Properti Disewa' : 'Semua Listing'

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="section-wrapper">
        {/* Header */}
        <div className="mb-8">
          <div className="divider-gold mb-3" />
          <h1 className="section-title">{title}</h1>
          <p className="text-gray-500 mt-2">{listings.length} properti ditemukan</p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-3 mb-8">
          {[
            { label: 'Semua',    href: '/listings' },
            { label: 'Dijual',   href: '/listings?type=Sale' },
            { label: 'Disewa',   href: '/listings?type=Rent' },
          ].map(f => (
            <Link key={f.href} href={f.href}
              className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all ${
                (f.href === '/listings' && !type) || f.href.includes(type || '')
                  ? 'bg-primary-900 text-white border-primary-900'
                  : 'border-gray-200 text-gray-600 hover:border-primary-300 bg-white'
              }`}>
              {f.label}
            </Link>
          ))}

          {/* Property Type filters */}
          {['Rumah', 'Apartemen', 'Ruko', 'Kavling', 'Gedung'].map(pt => (
            <Link key={pt}
              href={`/listings${type ? `?type=${type}&` : '?'}propertyType=${pt}`}
              className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all ${
                propertyType === pt
                  ? 'bg-gold text-primary-900 border-gold'
                  : 'border-gray-200 text-gray-600 hover:border-gold bg-white'
              }`}>
              {pt}
            </Link>
          ))}
        </div>

        {/* Grid */}
        {listings.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {listings.map(listing => <ListingCard key={listing.id} listing={listing} />)}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="font-display font-bold text-primary-900 text-xl mb-2">Properti tidak ditemukan</h3>
            <p className="text-gray-500 mb-6">Coba ubah filter pencarian Anda</p>
            <Link href="/listings" className="btn-primary">Lihat Semua Listing</Link>
          </div>
        )}
      </div>
    </div>
  )
}
