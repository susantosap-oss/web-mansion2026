'use client'

import { useState } from 'react'

const waOffice = process.env.NEXT_PUBLIC_WA_OFFICE || '6281234567890'

export default function TitipListingPage() {
  const [form, setForm] = useState({
    name: '', phone: '', email: '', propertyType: 'Rumah',
    address: '', price: '', description: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleWA = () => {
    const msg = `*Titip Listing Properti*\n\nNama: ${form.name}\nTelepon: ${form.phone}\nTipe: ${form.propertyType}\nAlamat: ${form.address}\nHarga: ${form.price}\nDeskripsi: ${form.description}`
    window.open(`https://wa.me/${waOffice}?text=${encodeURIComponent(msg)}`, '_blank')
    setSubmitted(true)
  }

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="section-wrapper max-w-2xl">
        <div className="text-center mb-8">
          <div className="divider-gold mx-auto mb-3" />
          <h1 className="section-title">Titip Listing Properti</h1>
          <p className="section-subtitle mx-auto">
            Percayakan penjualan atau penyewaan properti Anda kepada agen profesional Mansion Realty
          </p>
        </div>

        {!submitted ? (
          <div className="card p-8">
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label-field">Nama Lengkap *</label>
                  <input className="input-field" placeholder="John Doe"
                    value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
                </div>
                <div>
                  <label className="label-field">No. WhatsApp *</label>
                  <input className="input-field" placeholder="08123456789"
                    value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
                </div>
              </div>

              <div>
                <label className="label-field">Email</label>
                <input type="email" className="input-field" placeholder="john@email.com"
                  value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
              </div>

              <div>
                <label className="label-field">Tipe Properti *</label>
                <select className="input-field" value={form.propertyType}
                  onChange={e => setForm(p => ({ ...p, propertyType: e.target.value }))}>
                  {['Rumah', 'Apartemen', 'Ruko', 'Kavling', 'Gedung', 'Gudang', 'Lainnya'].map(t => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="label-field">Alamat / Lokasi Properti *</label>
                <input className="input-field" placeholder="Jl. Contoh No. 1, Jakarta Selatan"
                  value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} />
              </div>

              <div>
                <label className="label-field">Harga yang Diinginkan</label>
                <input className="input-field" placeholder="cth: 850.000.000 atau Negotiable"
                  value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} />
              </div>

              <div>
                <label className="label-field">Deskripsi Singkat</label>
                <textarea className="input-field h-28 resize-none" placeholder="Ceritakan kondisi properti, spesifikasi, dll..."
                  value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
              </div>

              <div className="flex gap-3 pt-2">
                <button onClick={handleWA} className="btn-wa flex-1 justify-center py-4">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                  </svg>
                  Kirim via WhatsApp
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="card p-12 text-center">
            <div className="text-6xl mb-4">✅</div>
            <h2 className="font-display font-bold text-primary-900 text-2xl mb-3">Terima Kasih!</h2>
            <p className="text-gray-600 font-body mb-6">
              Permintaan titip listing Anda telah kami terima. Tim agen kami akan segera menghubungi Anda.
            </p>
            <button onClick={() => setSubmitted(false)} className="btn-outline">
              Titip Listing Lagi
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
