import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { getListingBySlug, getListings, getAgentById, formatPrice, buildWALink } from '@/lib/sheets'
import { Listing } from '@/types'

export const revalidate = 300

interface Props { params: { slug: string } }

export async function generateStaticParams() {
  const listings = await getListings()
  return listings.map(l => ({ slug: l.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const listing = await getListingBySlug(params.slug)
  if (!listing) return {}
  return {
    title: `${listing.title} | ${formatPrice(listing.price)}`,
    description: listing.description.slice(0, 160),
    openGraph: {
      title: listing.title,
      description: listing.description.slice(0, 160),
      images: [{ url: listing.coverImage, width: 1200, height: 630, alt: listing.title }],
    },
  }
}

// ── JSON-LD Schema ────────────────────────────────────────
function RealEstateSchema({ listing }: { listing: Listing }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'RealEstateListing',
    name: listing.title,
    description: listing.description,
    url: `${process.env.NEXT_PUBLIC_SITE_URL}/listings/${listing.slug}`,
    image: listing.images.length > 0 ? listing.images : [listing.coverImage],
    offers: {
      '@type': 'Offer',
      price: listing.price,
      priceCurrency: 'IDR',
      availability: 'https://schema.org/InStock',
      seller: {
        '@type': 'RealEstateAgent',
        name: listing.agentName,
        telephone: listing.agentPhone,
      },
    },
    address: {
      '@type': 'PostalAddress',
      addressLocality: listing.city,
      addressRegion: listing.province,
      addressCountry: 'ID',
      streetAddress: listing.address,
    },
    floorSize: {
      '@type': 'QuantitativeValue',
      value: listing.luasBangunan,
      unitCode: 'MTK',
    },
    numberOfRooms: listing.kamarTidur,
    numberOfBathroomsTotal: listing.kamarMandi,
  }
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  )
}

export default async function ListingDetailPage({ params }: Props) {
  const listing = await getListingBySlug(params.slug)
  if (!listing) notFound()

  const agent = listing.agentId ? await getAgentById(listing.agentId) : null
  const waMessage = `Halo ${listing.agentName}, saya tertarik dengan properti:\n*${listing.title}*\nHarga: ${formatPrice(listing.price)}\n\nBisa info lebih lanjut?`
  const waLink    = buildWALink(listing.agentPhone, waMessage)

  return (
    <>
      <RealEstateSchema listing={listing} />

      <div className="pt-24 pb-16 bg-white">
        <div className="section-wrapper">
          {/* Breadcrumb */}
          <nav className="text-sm text-gray-500 mb-6 flex items-center gap-2">
            <Link href="/" className="hover:text-primary-900">Beranda</Link>
            <span>/</span>
            <Link href="/listings" className="hover:text-primary-900">Listing</Link>
            <span>/</span>
            <span className="text-primary-900 font-semibold truncate max-w-xs">{listing.title}</span>
          </nav>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* ── LEFT: Main Content ── */}
            <div className="lg:col-span-2">
              {/* Image Gallery */}
              <div className="rounded-2xl overflow-hidden mb-6">
                <div className="relative h-80 md:h-[460px]">
                  <Image
                    src={listing.coverImage || '/images/placeholder-property.jpg'}
                    alt={listing.title}
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className={listing.type === 'Sale' ? 'badge-sale' : 'badge-rent'}>
                      {listing.type === 'Sale' ? '🏷 Dijual' : '🔑 Disewa'}
                    </span>
                    <span className="badge bg-white/90 text-gray-700">{listing.propertyType}</span>
                  </div>
                </div>

                {listing.images.length > 1 && (
                  <div className="grid grid-cols-4 gap-1 mt-1">
                    {listing.images.slice(1, 5).map((img, i) => (
                      <div key={i} className="relative h-24 overflow-hidden rounded">
                        <Image src={img} alt={`${listing.title} ${i+2}`} fill className="object-cover hover:scale-105 transition-transform cursor-pointer"/>
                        {i === 3 && listing.images.length > 5 && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                            <span className="text-white font-bold">+{listing.images.length - 5}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Title + Price */}
              <h1 className="text-3xl font-display font-bold text-primary-900 mb-2">{listing.title}</h1>
              <p className="text-gray-500 flex items-center gap-1 mb-4">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                </svg>
                {listing.address}, {listing.city}, {listing.province}
              </p>

              <div className="flex items-baseline gap-3 mb-8">
                <span className="text-4xl font-display font-bold text-primary-900">{formatPrice(listing.price)}</span>
                <span className="text-gray-400 font-body">{listing.priceUnit !== 'Jual' ? `/ ${listing.priceUnit.replace('Sewa/', '')}` : ''}</span>
              </div>

              {/* Specs Grid */}
              <div className="bg-gray-50 rounded-2xl p-6 mb-8">
                <h2 className="font-display font-bold text-primary-900 mb-4">Spesifikasi Properti</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {[
                    { icon: '📐', label: 'Luas Tanah',     value: `${listing.luasTanah} m²` },
                    { icon: '🏗',  label: 'Luas Bangunan', value: `${listing.luasBangunan} m²` },
                    { icon: '🛏',  label: 'Kamar Tidur',   value: `${listing.kamarTidur} KT` },
                    { icon: '🚿',  label: 'Kamar Mandi',   value: `${listing.kamarMandi} KM` },
                    { icon: '🚗',  label: 'Carport',       value: `${listing.carport} Mobil` },
                    { icon: '🏢',  label: 'Lantai',        value: `${listing.lantai} Lantai` },
                    { icon: '📄',  label: 'Sertifikat',    value: listing.sertifikat },
                    { icon: '🏚',  label: 'Kondisi',       value: listing.kondisi },
                  ].map(spec => (
                    <div key={spec.label} className="bg-white rounded-xl p-3 border border-gray-100">
                      <div className="text-xl mb-1">{spec.icon}</div>
                      <div className="text-xs text-gray-400">{spec.label}</div>
                      <div className="font-semibold text-primary-900 text-sm">{spec.value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h2 className="font-display font-bold text-primary-900 mb-4">Deskripsi</h2>
                <div className="prose prose-sm max-w-none text-gray-600 font-body leading-relaxed whitespace-pre-line">
                  {listing.description}
                </div>
              </div>
            </div>

            {/* ── RIGHT: Agent Card + CTA ── */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 space-y-4">
                {/* Agent Card */}
                <div className="card p-5">
                  <h3 className="font-display font-semibold text-primary-900 mb-4 text-sm uppercase tracking-wide">
                    Hubungi Agen
                  </h3>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-200 flex-shrink-0">
                      {listing.agentPhoto ? (
                        <Image src={listing.agentPhoto} alt={listing.agentName} width={56} height={56} className="object-cover w-full h-full"/>
                      ) : (
                        <div className="w-full h-full bg-primary-100 flex items-center justify-center text-primary-900 font-bold text-xl">
                          {listing.agentName.charAt(0)}
                        </div>
                      )}
                    </div>
                    <div>
                      <p className="font-display font-bold text-primary-900">{listing.agentName}</p>
                      <p className="text-xs text-gray-500">Agen Properti</p>
                      {agent?.verified && (
                        <span className="badge bg-blue-50 text-blue-700 text-xs mt-1">✓ Terverifikasi</span>
                      )}
                    </div>
                  </div>

                  <a href={waLink} target="_blank" rel="noopener noreferrer" className="btn-wa w-full justify-center mb-3">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    Chat via WhatsApp
                  </a>

                  {agent?.id && (
                    <Link href={`/agents/${agent.id}`} className="block text-center text-sm text-primary-700 hover:text-primary-900 font-semibold">
                      Lihat Profil Agen →
                    </Link>
                  )}
                </div>

                {/* Quick Info */}
                <div className="card p-5 bg-primary-50 border-primary-100">
                  <h4 className="font-display font-semibold text-primary-900 mb-3 text-sm">Informasi Listing</h4>
                  <dl className="space-y-2 text-sm">
                    {[
                      { dt: 'ID Listing',  dd: listing.id },
                      { dt: 'Status',      dd: listing.status },
                      { dt: 'Diperbarui', dd: new Date(listing.updatedAt).toLocaleDateString('id-ID') },
                    ].map(item => (
                      <div key={item.dt} className="flex justify-between">
                        <dt className="text-gray-500">{item.dt}</dt>
                        <dd className="font-semibold text-primary-900">{item.dd}</dd>
                      </div>
                    ))}
                  </dl>
                </div>

                {/* KPR CTA */}
                <div className="card p-5 border-gold bg-amber-50">
                  <p className="text-sm font-body text-gray-600 mb-2">💡 Ingin tahu cicilan KPR?</p>
                  <Link href={`/calculator?harga=${listing.price}&type=konvensional`} className="btn-primary w-full justify-center text-sm">
                    Hitung Simulasi KPR
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
