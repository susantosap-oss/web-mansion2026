import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { getAgents, buildWALink } from '@/lib/sheets'

export const revalidate = 600

export const metadata: Metadata = {
  title: 'Daftar Agen Properti | Mansion Realty',
  description: 'Temukan agen properti berpengalaman dan terverifikasi Mansion Realty. Siap membantu Anda menemukan properti terbaik.',
}

export default async function AgentsPage() {
  const agents = await getAgents()

  return (
    <div className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="section-wrapper">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="divider-gold mx-auto mb-3" />
          <h1 className="section-title">Tim Agen Mansion Realty</h1>
          <p className="section-subtitle mx-auto">
            Agen berpengalaman, terverifikasi, dan siap membantu Anda 24/7
          </p>
        </div>

        {agents.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <div className="text-6xl mb-4">👤</div>
            <p>Data agen belum tersedia.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {agents.map(agent => {
              const waMsg  = `Halo ${agent.name}, saya ingin konsultasi properti dengan Anda.`
              const waLink = buildWALink(agent.whatsapp || agent.phone, waMsg)

              return (
                <div key={agent.id} className="card p-5 text-center hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1">
                  {/* Photo */}
                  <div className="relative w-24 h-24 mx-auto mb-4">
                    <div className="w-24 h-24 rounded-full overflow-hidden bg-primary-100 ring-4 ring-primary-50">
                      {agent.photo ? (
                        <Image src={agent.photo} alt={agent.name} width={96} height={96} className="object-cover w-full h-full"/>
                      ) : (
                        <div className="w-full h-full bg-primary-900 flex items-center justify-center text-white font-display text-3xl font-bold">
                          {agent.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    {agent.verified && (
                      <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-blue-500 rounded-full
                                      flex items-center justify-center text-white text-xs font-bold border-2 border-white"
                           title="Agen Terverifikasi">✓</div>
                    )}
                  </div>

                  {/* Info */}
                  <h3 className="font-display font-bold text-primary-900 text-lg leading-tight">{agent.name}</h3>

                  {agent.specialization.length > 0 && (
                    <p className="text-xs text-gray-500 mt-1 font-body">
                      {agent.specialization.slice(0, 2).join(' · ')}
                    </p>
                  )}

                  {agent.areas.length > 0 && (
                    <p className="text-xs text-primary-700 mt-1 font-semibold">
                      📍 {agent.areas.slice(0, 2).join(', ')}
                    </p>
                  )}

                  {/* Stats */}
                  <div className="flex justify-center gap-4 mt-4 py-3 border-t border-b border-gray-100">
                    <div className="text-center">
                      <div className="font-display font-bold text-primary-900">{agent.totalListings}</div>
                      <div className="text-xs text-gray-400">Listing</div>
                    </div>
                    <div className="text-center">
                      <div className="font-display font-bold text-primary-900">{agent.totalDeals}</div>
                      <div className="text-xs text-gray-400">Deal</div>
                    </div>
                    <div className="text-center">
                      <div className="font-display font-bold text-gold">
                        {'★'.repeat(Math.round(agent.rating))}
                      </div>
                      <div className="text-xs text-gray-400">{agent.rating.toFixed(1)}</div>
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="flex gap-2 mt-4">
                    <Link href={`/agents/${agent.id}`}
                      className="flex-1 py-2 text-sm font-semibold border border-primary-200
                                 text-primary-900 rounded-lg hover:bg-primary-50 transition-colors text-center">
                      Profil
                    </Link>
                    <a href={waLink} target="_blank" rel="noopener noreferrer"
                       className="flex-1 py-2 text-sm font-semibold bg-[#25D366] text-white
                                  rounded-lg hover:bg-[#1da851] transition-colors text-center">
                      WA
                    </a>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* CTA Join */}
        <div className="mt-16 bg-primary-900 rounded-3xl p-10 text-center">
          <h2 className="text-3xl font-display font-bold text-white mb-3">
            Ingin Bergabung sebagai Agen?
          </h2>
          <p className="text-white/70 font-body mb-6 max-w-lg mx-auto">
            Jadilah bagian dari tim profesional Mansion Realty dan tingkatkan karir Anda di industri properti.
          </p>
          <a href={`https://wa.me/${process.env.NEXT_PUBLIC_WA_OFFICE || '6281234567890'}?text=Halo%20Mansion%20Realty%2C%20saya%20ingin%20mendaftar%20sebagai%20agen`}
             target="_blank" rel="noopener noreferrer" className="btn-gold px-8 py-4 text-base">
            Daftar Jadi Agen →
          </a>
        </div>
      </div>
    </div>
  )
}
