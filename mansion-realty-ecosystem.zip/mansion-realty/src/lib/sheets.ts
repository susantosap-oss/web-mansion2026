/**
 * MANSION REALTY — Google Sheets API Bridge
 * 
 * Strategy: Apps Script Web App sebagai API perantara,
 * dengan ISR caching di Next.js untuk performa optimal.
 */

import { Project, Listing, Agent, News, SheetRow, APIResponse } from '@/types'

const GAS_URL = process.env.NEXT_PUBLIC_GAS_API_URL!
const GAS_SECRET = process.env.GAS_API_SECRET || ''

// ── In-Memory Cache (Server-Side) ──────────────────────────
interface CacheEntry<T> {
  data: T
  expiresAt: number
}
const cache = new Map<string, CacheEntry<unknown>>()

function getCached<T>(key: string): T | null {
  const entry = cache.get(key)
  if (!entry) return null
  if (Date.now() > entry.expiresAt) {
    cache.delete(key)
    return null
  }
  return entry.data as T
}

function setCached<T>(key: string, data: T, ttlSeconds = 300): void {
  cache.set(key, { data, expiresAt: Date.now() + ttlSeconds * 1000 })
}

// ── GAS Fetcher ────────────────────────────────────────────
async function fetchFromGAS<T>(
  action: string,
  params: Record<string, string> = {},
  ttl = 300
): Promise<T> {
  const cacheKey = `gas:${action}:${JSON.stringify(params)}`
  const cached = getCached<T>(cacheKey)
  if (cached) return cached

  const url = new URL(GAS_URL)
  url.searchParams.set('action', action)
  url.searchParams.set('secret', GAS_SECRET)
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))

  const res = await fetch(url.toString(), {
    next: { revalidate: ttl },
    headers: { 'Content-Type': 'application/json' },
  })

  if (!res.ok) throw new Error(`GAS API error: ${res.status} ${res.statusText}`)

  const json: APIResponse<T> = await res.json()
  if (!json.success) throw new Error(json.error || 'GAS API returned error')

  setCached(cacheKey, json.data as T, ttl)
  return json.data as T
}

// ── Sheet Mapper Helpers ───────────────────────────────────
function mapProject(row: SheetRow): Project {
  return {
    id:          String(row['ID'] || ''),
    slug:        String(row['Slug'] || ''),
    name:        String(row['Nama Proyek'] || ''),
    developer:   String(row['Developer'] || ''),
    location:    String(row['Lokasi'] || ''),
    city:        String(row['Kota'] || ''),
    province:    String(row['Provinsi'] || ''),
    priceMin:    Number(row['Harga Min'] || 0),
    priceMax:    Number(row['Harga Max'] || 0),
    type:        (row['Tipe'] as Project['type']) || 'Perumahan',
    status:      (row['Status'] as Project['status']) || 'Aktif',
    description: String(row['Deskripsi'] || ''),
    coverImage:  String(row['Cover Image'] || ''),
    images:      String(row['Gambar'] || '').split(',').map(s => s.trim()).filter(Boolean),
    specs: {
      luasTanah:    row['LT'] ? String(row['LT']) : undefined,
      luasBangunan: row['LB'] ? String(row['LB']) : undefined,
      kamarTidur:   row['KT'] ? Number(row['KT']) : undefined,
      kamarMandi:   row['KM'] ? Number(row['KM']) : undefined,
      carport:      row['CP'] ? Number(row['CP']) : undefined,
      listrikDaya:  row['Listrik'] ? String(row['Listrik']) : undefined,
      airBersih:    row['Air'] ? String(row['Air']) : undefined,
    },
    facilities:  String(row['Fasilitas'] || '').split(',').map(s => s.trim()).filter(Boolean),
    agentId:     String(row['Agent ID'] || ''),
    createdAt:   String(row['Created At'] || ''),
    updatedAt:   String(row['Updated At'] || ''),
  }
}

function mapListing(row: SheetRow): Listing {
  return {
    id:            String(row['ID'] || ''),
    slug:          String(row['Slug'] || ''),
    title:         String(row['Judul'] || ''),
    type:          (row['Tipe'] as Listing['type']) || 'Sale',
    propertyType:  (row['Tipe Properti'] as Listing['propertyType']) || 'Rumah',
    price:         Number(row['Harga'] || 0),
    priceUnit:     (row['Satuan Harga'] as Listing['priceUnit']) || 'Jual',
    location:      String(row['Lokasi'] || ''),
    address:       String(row['Alamat'] || ''),
    city:          String(row['Kota'] || ''),
    province:      String(row['Provinsi'] || ''),
    luasTanah:     Number(row['LT'] || 0),
    luasBangunan:  Number(row['LB'] || 0),
    kamarTidur:    Number(row['KT'] || 0),
    kamarMandi:    Number(row['KM'] || 0),
    carport:       Number(row['CP'] || 0),
    lantai:        Number(row['Lantai'] || 1),
    kondisi:       (row['Kondisi'] as Listing['kondisi']) || 'Bagus',
    sertifikat:    (row['Sertifikat'] as Listing['sertifikat']) || 'SHM',
    description:   String(row['Deskripsi'] || ''),
    coverImage:    String(row['Cover Image'] || ''),
    images:        String(row['Gambar'] || '').split(',').map(s => s.trim()).filter(Boolean),
    agentId:       String(row['Agent ID'] || ''),
    agentName:     String(row['Nama Agen'] || ''),
    agentPhone:    String(row['WA Agen'] || ''),
    agentPhoto:    String(row['Foto Agen'] || ''),
    viewCount:     Number(row['Views'] || 0),
    leadCount:     Number(row['Leads'] || 0),
    status:        (row['Status'] as Listing['status']) || 'Aktif',
    featured:      row['Featured'] === 'TRUE' || row['Featured'] === true,
    createdAt:     String(row['Created At'] || ''),
    updatedAt:     String(row['Updated At'] || ''),
  }
}

function mapAgent(row: SheetRow): Agent {
  return {
    id:             String(row['ID'] || ''),
    name:           String(row['Nama'] || ''),
    photo:          String(row['Foto'] || ''),
    phone:          String(row['Telepon'] || ''),
    email:          String(row['Email'] || ''),
    whatsapp:       String(row['WhatsApp'] || ''),
    bio:            String(row['Bio'] || ''),
    specialization: String(row['Spesialisasi'] || '').split(',').map(s => s.trim()).filter(Boolean),
    areas:          String(row['Area'] || '').split(',').map(s => s.trim()).filter(Boolean),
    totalListings:  Number(row['Total Listing'] || 0),
    totalDeals:     Number(row['Total Deal'] || 0),
    rating:         Number(row['Rating'] || 5),
    verified:       row['Verified'] === 'TRUE' || row['Verified'] === true,
    joinDate:       String(row['Join Date'] || ''),
    instagram:      row['Instagram'] ? String(row['Instagram']) : undefined,
    linkedin:       row['LinkedIn'] ? String(row['LinkedIn']) : undefined,
  }
}

function mapNews(row: SheetRow): News {
  return {
    id:          String(row['ID'] || ''),
    slug:        String(row['Slug'] || ''),
    title:       String(row['Judul'] || ''),
    summary:     String(row['Ringkasan'] || ''),
    content:     String(row['Konten'] || ''),
    coverImage:  String(row['Cover Image'] || ''),
    category:    (row['Kategori'] as News['category']) || 'Berita Properti',
    author:      String(row['Penulis'] || ''),
    publishedAt: String(row['Tanggal'] || ''),
    tags:        String(row['Tags'] || '').split(',').map(s => s.trim()).filter(Boolean),
    viewCount:   Number(row['Views'] || 0),
  }
}

// ── Public API Functions ───────────────────────────────────
export async function getProjects(): Promise<Project[]> {
  const rows = await fetchFromGAS<SheetRow[]>('getProjects', {}, 300)
  return rows.map(mapProject)
}

export async function getProjectBySlug(slug: string): Promise<Project | null> {
  const rows = await fetchFromGAS<SheetRow[]>('getProjects', {}, 300)
  const row = rows.find(r => r['Slug'] === slug)
  return row ? mapProject(row) : null
}

export async function getListings(filter?: {
  type?: 'Sale' | 'Rent'
  city?: string
  propertyType?: string
  featured?: boolean
}): Promise<Listing[]> {
  const rows = await fetchFromGAS<SheetRow[]>('getListings', {}, 300)
  let listings = rows.map(mapListing).filter(l => l.status === 'Aktif')

  if (filter?.type)         listings = listings.filter(l => l.type === filter.type)
  if (filter?.city)         listings = listings.filter(l => l.city === filter.city)
  if (filter?.propertyType) listings = listings.filter(l => l.propertyType === filter.propertyType)
  if (filter?.featured)     listings = listings.filter(l => l.featured)

  return listings
}

export async function getListingBySlug(slug: string): Promise<Listing | null> {
  const rows = await fetchFromGAS<SheetRow[]>('getListings', {}, 300)
  const row = rows.find(r => r['Slug'] === slug)
  return row ? mapListing(row) : null
}

export async function getAgents(): Promise<Agent[]> {
  const rows = await fetchFromGAS<SheetRow[]>('getAgents', {}, 600)
  return rows.map(mapAgent)
}

export async function getAgentById(id: string): Promise<Agent | null> {
  const agents = await getAgents()
  return agents.find(a => a.id === id) || null
}

export async function getNews(limit?: number): Promise<News[]> {
  const rows = await fetchFromGAS<SheetRow[]>('getNews', {}, 600)
  const news = rows.map(mapNews).sort(
    (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  )
  return limit ? news.slice(0, limit) : news
}

export async function getNewsBySlug(slug: string): Promise<News | null> {
  const rows = await fetchFromGAS<SheetRow[]>('getNews', {}, 600)
  const row = rows.find(r => r['Slug'] === slug)
  return row ? mapNews(row) : null
}

// ── Utility ────────────────────────────────────────────────
export function formatPrice(price: number): string {
  if (price >= 1_000_000_000) {
    const m = price / 1_000_000_000
    return `Rp ${m % 1 === 0 ? m.toFixed(0) : m.toFixed(1)} M`
  }
  if (price >= 1_000_000) {
    const j = price / 1_000_000
    return `Rp ${j % 1 === 0 ? j.toFixed(0) : j.toFixed(1)} Jt`
  }
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(price)
}

export function buildWALink(phone: string, message: string): string {
  const clean = phone.replace(/\D/g, '')
  const normalized = clean.startsWith('0') ? '62' + clean.slice(1) : clean
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`
}
