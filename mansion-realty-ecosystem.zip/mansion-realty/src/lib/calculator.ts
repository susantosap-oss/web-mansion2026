import { KPRParams, KPRResult } from '@/types'

// ── KPR Konvensional (Flat/Anuitas) ──────────────────────
export function calculateKPRKonvensional(params: KPRParams): KPRResult {
  const { hargaProperti, uangMuka, tenor, bungaTahunan } = params
  const pokokPinjaman = hargaProperti - uangMuka
  const bungaBulanan  = bungaTahunan / 100 / 12
  const totalBulan    = tenor * 12

  // Rumus anuitas
  const angsuran =
    bungaBulanan === 0
      ? pokokPinjaman / totalBulan
      : (pokokPinjaman * bungaBulanan * Math.pow(1 + bungaBulanan, totalBulan)) /
        (Math.pow(1 + bungaBulanan, totalBulan) - 1)

  const breakdown: KPRResult['breakdown'] = []
  let sisaPokok = pokokPinjaman

  for (let i = 1; i <= totalBulan; i++) {
    const bunga  = sisaPokok * bungaBulanan
    const pokok  = angsuran - bunga
    sisaPokok   -= pokok
    breakdown.push({
      bulan: i,
      angsuran: Math.round(angsuran),
      pokok:    Math.round(pokok),
      bunga:    Math.round(bunga),
      sisaPokok: Math.max(0, Math.round(sisaPokok)),
    })
  }

  const totalPembayaran = angsuran * totalBulan
  return {
    pokokPinjaman:   Math.round(pokokPinjaman),
    angsuranPokok:   Math.round(pokokPinjaman / totalBulan),
    angsuranBunga:   Math.round(angsuran - pokokPinjaman / totalBulan),
    totalAngsuran:   Math.round(angsuran),
    totalPembayaran: Math.round(totalPembayaran),
    totalBunga:      Math.round(totalPembayaran - pokokPinjaman),
    breakdown,
  }
}

// ── KPR Syariah (Murabahah - Margin Flat) ────────────────
export function calculateKPRSyariah(params: KPRParams): KPRResult {
  const { hargaProperti, uangMuka, tenor, bungaTahunan } = params
  const pokokPinjaman = hargaProperti - uangMuka
  const totalBulan    = tenor * 12
  const marginRate    = bungaTahunan / 100 // sudah per tahun (flat)

  const totalMargin   = pokokPinjaman * marginRate * tenor
  const hargaJual     = pokokPinjaman + totalMargin
  const angsuran      = hargaJual / totalBulan

  const breakdown: KPRResult['breakdown'] = []
  for (let i = 1; i <= totalBulan; i++) {
    const pokok  = pokokPinjaman / totalBulan
    const margin = (pokokPinjaman * marginRate) / 12
    breakdown.push({
      bulan:    i,
      angsuran: Math.round(angsuran),
      pokok:    Math.round(pokok),
      bunga:    Math.round(margin),
      sisaPokok: Math.round(pokokPinjaman - (pokok * i)),
    })
  }

  return {
    pokokPinjaman:   Math.round(pokokPinjaman),
    angsuranPokok:   Math.round(pokokPinjaman / totalBulan),
    angsuranBunga:   Math.round((totalMargin / totalBulan)),
    totalAngsuran:   Math.round(angsuran),
    totalPembayaran: Math.round(hargaJual),
    totalBunga:      Math.round(totalMargin),
    breakdown,
  }
}

// ── KMG (Kredit Multiguna) ────────────────────────────────
export function calculateKMG(params: KPRParams): KPRResult {
  // KMG biasanya flat rate, agunan properti
  return calculateKPRKonvensional({
    ...params,
    bungaTahunan: params.bungaTahunan + 2, // biasanya ~2% lebih tinggi
  })
}

// ── Take Over ────────────────────────────────────────────
export function calculateTakeOver(params: KPRParams & {
  sisaPokok?: number
  sisaTenor?: number
}): KPRResult {
  const {
    sisaPokok   = params.hargaProperti * 0.6,
    sisaTenor   = params.tenor,
    bungaTahunan,
  } = params

  return calculateKPRKonvensional({
    hargaProperti: sisaPokok,
    uangMuka: 0,
    tenor: sisaTenor,
    bungaTahunan,
    jenis: 'takeover',
  })
}

// ── Master Calculator ─────────────────────────────────────
export function calculate(params: KPRParams): KPRResult {
  switch (params.jenis) {
    case 'syariah':     return calculateKPRSyariah(params)
    case 'kmg':         return calculateKMG(params)
    case 'takeover':    return calculateTakeOver(params)
    default:            return calculateKPRKonvensional(params)
  }
}

// ── Bank Rate Presets ─────────────────────────────────────
export const BANK_PRESETS: Array<{
  bank: string
  logo: string
  type: 'konvensional' | 'syariah'
  rate: number
  maxTenor: number
  maxFinancing: number
  notes: string
}> = [
  { bank: 'BTN',        logo: '/images/banks/btn.png',    type: 'konvensional', rate: 7.5,  maxTenor: 30, maxFinancing: 90, notes: 'Subsidi FLPP tersedia' },
  { bank: 'BCA',        logo: '/images/banks/bca.png',    type: 'konvensional', rate: 7.75, maxTenor: 25, maxFinancing: 80, notes: 'Fixed 2 tahun pertama' },
  { bank: 'Mandiri',    logo: '/images/banks/mandiri.png',type: 'konvensional', rate: 7.5,  maxTenor: 30, maxFinancing: 80, notes: 'KPR Mandiri Griya' },
  { bank: 'BRI',        logo: '/images/banks/bri.png',    type: 'konvensional', rate: 7.25, maxTenor: 30, maxFinancing: 80, notes: 'BRI Griya' },
  { bank: 'BSI',        logo: '/images/banks/bsi.png',    type: 'syariah',      rate: 8.0,  maxTenor: 30, maxFinancing: 80, notes: 'Akad Murabahah' },
  { bank: 'BNI Syariah',logo: '/images/banks/bni.png',   type: 'syariah',      rate: 8.5,  maxTenor: 25, maxFinancing: 80, notes: 'Griya iB Hasanah' },
]
