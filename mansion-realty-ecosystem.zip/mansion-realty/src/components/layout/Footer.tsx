import Link from 'next/link'

const footerLinks = {
  'Properti': [
    { label: 'Proyek Baru',    href: '/projects' },
    { label: 'Rumah Dijual',   href: '/listings?type=Sale&propertyType=Rumah' },
    { label: 'Apartemen Dijual', href: '/listings?type=Sale&propertyType=Apartemen' },
    { label: 'Rumah Disewa',   href: '/listings?type=Rent&propertyType=Rumah' },
    { label: 'Kavling',        href: '/listings?propertyType=Kavling' },
  ],
  'Layanan': [
    { label: 'KPR & Pembiayaan', href: '/calculator' },
    { label: 'Titip Listing',    href: '/listings/titip' },
    { label: 'Daftar Agen',      href: '/agents' },
    { label: 'Berita Properti',  href: '/news' },
    { label: 'Tentang Kami',     href: '/about' },
  ],
  'Perusahaan': [
    { label: 'Tentang Mansion', href: '/about' },
    { label: 'Karir',           href: '/career' },
    { label: 'Kebijakan Privasi',href: '/privacy' },
    { label: 'Syarat & Ketentuan',href: '/terms' },
    { label: 'Hubungi Kami',    href: '/contact' },
  ],
}

export default function Footer() {
  const year = new Date().getFullYear()
  const waOffice = process.env.NEXT_PUBLIC_WA_OFFICE || '6281234567890'

  return (
    <footer className="bg-primary-900 text-white">
      {/* CTA Strip */}
      <div className="bg-gold py-8">
        <div className="section-wrapper flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-display font-bold text-2xl text-primary-900">
              Siap menemukan properti impian Anda?
            </h3>
            <p className="text-primary-900/70 font-body mt-1">
              Konsultasikan kebutuhan properti Anda dengan agen terpercaya kami.
            </p>
          </div>
          <a
            href={`https://wa.me/${waOffice}?text=Halo%20Mansion%20Realty%2C%20saya%20ingin%20konsultasi%20properti`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 inline-flex items-center gap-2 px-6 py-3 bg-primary-900 text-white
                       font-body font-bold rounded-lg hover:bg-primary-800 transition-colors duration-200"
          >
            <svg className="w-5 h-5 text-[#25D366]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
            </svg>
            Konsultasi Gratis via WhatsApp
          </a>
        </div>
      </div>

      {/* Main Footer */}
      <div className="section-wrapper py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-primary-900 font-display font-bold text-lg">M</span>
              </div>
              <span className="text-white font-display font-bold text-xl">
                Mansion <span className="text-gold">Realty</span>
              </span>
            </div>
            <p className="text-white/60 font-body text-sm leading-relaxed max-w-xs">
              Agen properti terpercaya yang membantu Anda menemukan hunian dan investasi properti terbaik di Indonesia.
            </p>

            <div className="mt-6 space-y-2 text-sm text-white/70">
              <p>📍 {process.env.NEXT_PUBLIC_COMPANY_ADDRESS || 'Jakarta Selatan'}</p>
              <p>📞 {process.env.NEXT_PUBLIC_COMPANY_PHONE || '+6221-1234-5678'}</p>
              <p>✉️ {process.env.NEXT_PUBLIC_COMPANY_EMAIL || 'info@mansionrealty.co.id'}</p>
            </div>

            {/* Social */}
            <div className="flex gap-3 mt-6">
              {[
                { icon: 'IG', label: 'Instagram', href: '#' },
                { icon: 'FB', label: 'Facebook', href: '#' },
                { icon: 'YT', label: 'YouTube', href: '#' },
              ].map(s => (
                <a key={s.icon} href={s.href} target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 bg-white/10 hover:bg-gold hover:text-primary-900 text-white
                             rounded-lg flex items-center justify-center text-xs font-bold
                             transition-all duration-200" aria-label={s.label}>
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="text-white font-display font-semibold mb-4">{title}</h4>
              <ul className="space-y-2">
                {links.map(link => (
                  <li key={link.href}>
                    <Link href={link.href}
                      className="text-sm text-white/60 hover:text-gold transition-colors duration-200">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-10 pt-6 flex flex-col sm:flex-row
                        items-center justify-between gap-3 text-sm text-white/40">
          <p>© {year} Mansion Realty. Semua hak dilindungi.</p>
          <p>Dibangun dengan ❤️ untuk ekosistem properti Indonesia</p>
        </div>
      </div>
    </footer>
  )
}
