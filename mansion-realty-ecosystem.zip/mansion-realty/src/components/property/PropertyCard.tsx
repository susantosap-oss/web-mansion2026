import Link from 'next/link'
import Image from 'next/image'
import { Listing, Project } from '@/types'
import { formatPrice, buildWALink } from '@/lib/sheets'

// ── Listing Card ──────────────────────────────────────────
interface ListingCardProps {
  listing: Listing
  className?: string
}

export function ListingCard({ listing, className = '' }: ListingCardProps) {
  const waMessage = `Halo ${listing.agentName}, saya tertarik dengan listing: ${listing.title}. Bisa info lebih lanjut?`
  const waLink    = buildWALink(listing.agentPhone, waMessage)

  return (
    <div className={`card group property-card ${className}`}>
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <Image
          src={listing.coverImage || '/images/placeholder-property.jpg'}
          alt={listing.title}
          fill
          className="object-cover property-image"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        {/* Overlay badges */}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={listing.type === 'Sale' ? 'badge-sale' : 'badge-rent'}>
            {listing.type === 'Sale' ? 'Dijual' : 'Disewa'}
          </span>
          {listing.featured && <span className="badge-new">⭐ Unggulan</span>}
        </div>
        {/* Agent chip */}
        <div className="absolute bottom-3 right-3 flex items-center gap-2 
                        bg-black/60 backdrop-blur-sm rounded-full px-3 py-1.5">
          <div className="w-6 h-6 rounded-full overflow-hidden bg-gray-300">
            {listing.agentPhoto && (
              <Image src={listing.agentPhoto} alt={listing.agentName} width={24} height={24} className="object-cover"/>
            )}
          </div>
          <span className="text-white text-xs font-semibold">{listing.agentName}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <p className="text-xs text-gray-400 font-body mb-1 flex items-center gap-1">
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
          </svg>
          {listing.location}, {listing.city}
        </p>

        <Link href={`/listings/${listing.slug}`}>
          <h3 className="font-display font-semibold text-primary-900 hover:text-primary-700 
                         transition-colors line-clamp-2 mb-2 leading-snug">
            {listing.title}
          </h3>
        </Link>

        <p className="price-display mb-3">{formatPrice(listing.price)}</p>

        {/* Specs */}
        <div className="flex items-center gap-3 text-xs text-gray-500 border-t border-gray-100 pt-3">
          {listing.luasTanah > 0 && (
            <span title="Luas Tanah">🏠 {listing.luasTanah}m²</span>
          )}
          {listing.luasBangunan > 0 && (
            <span title="Luas Bangunan">📐 {listing.luasBangunan}m²</span>
          )}
          {listing.kamarTidur > 0 && (
            <span title="Kamar Tidur">🛏 {listing.kamarTidur}</span>
          )}
          {listing.kamarMandi > 0 && (
            <span title="Kamar Mandi">🚿 {listing.kamarMandi}</span>
          )}
        </div>

        {/* CTA */}
        <div className="flex gap-2 mt-3">
          <Link href={`/listings/${listing.slug}`} className="flex-1 text-center py-2 text-sm font-semibold
            text-primary-900 border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors">
            Detail
          </Link>
          <a href={waLink} target="_blank" rel="noopener noreferrer"
            className="flex-1 text-center py-2 text-sm font-semibold text-white
            bg-[#25D366] rounded-lg hover:bg-[#1da851] transition-colors flex items-center justify-center gap-1">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
            </svg>
            WA Agen
          </a>
        </div>
      </div>
    </div>
  )
}

// ── Project Card ──────────────────────────────────────────
interface ProjectCardProps {
  project: Project
  className?: string
}

export function ProjectCard({ project, className = '' }: ProjectCardProps) {
  return (
    <div className={`card group property-card ${className}`}>
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <Image
          src={project.coverImage || '/images/placeholder-project.jpg'}
          alt={project.name}
          fill
          className="object-cover property-image"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <span className="badge bg-primary-900 text-white">{project.type}</span>
          {project.status === 'Coming Soon' && (
            <span className="badge bg-amber-500 text-white">Coming Soon</span>
          )}
          {project.status === 'Sold Out' && (
            <span className="badge bg-red-500 text-white">Sold Out</span>
          )}
        </div>
        {/* Developer chip */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
          <p className="text-white/80 text-xs">Developer</p>
          <p className="text-white font-semibold text-sm">{project.developer}</p>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <p className="text-xs text-gray-400 font-body mb-1 flex items-center gap-1">
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
          </svg>
          {project.location}, {project.city}
        </p>

        <Link href={`/projects/${project.slug}`}>
          <h3 className="font-display font-semibold text-primary-900 hover:text-primary-700
                         transition-colors leading-snug mb-2">
            {project.name}
          </h3>
        </Link>

        <p className="text-sm text-gray-500 line-clamp-2 font-body mb-3">{project.description}</p>

        {/* Price range */}
        <div className="bg-primary-50 rounded-lg p-2.5 mb-3">
          <p className="text-xs text-gray-500">Mulai dari</p>
          <p className="price-display text-lg">{formatPrice(project.priceMin)}</p>
          {project.priceMax > project.priceMin && (
            <p className="text-xs text-gray-400">s/d {formatPrice(project.priceMax)}</p>
          )}
        </div>

        {/* Specs preview */}
        {(project.specs.kamarTidur || project.specs.luasTanah) && (
          <div className="flex gap-3 text-xs text-gray-500 mb-3">
            {project.specs.luasTanah   && <span>LT: {project.specs.luasTanah}</span>}
            {project.specs.luasBangunan && <span>LB: {project.specs.luasBangunan}</span>}
            {project.specs.kamarTidur  && <span>🛏 {project.specs.kamarTidur} KT</span>}
          </div>
        )}

        <Link href={`/projects/${project.slug}`}
          className="block w-full text-center btn-primary py-2.5 text-sm">
          Lihat Detail Proyek
        </Link>
      </div>
    </div>
  )
}
