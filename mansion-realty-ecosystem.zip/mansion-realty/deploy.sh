#!/bin/bash
# ============================================================
# MANSION REALTY — GCP Deployment Script
# Jalankan dari Google Cloud Shell Console
# ============================================================
set -euo pipefail

# ── CONFIG: Ganti sesuai kebutuhan Anda ───────────────────
PROJECT_ID="mansion-realty-prod"        # Ganti dengan GCP Project ID Anda
REGION="asia-southeast2"                # Jakarta
SERVICE_NAME="mansion-realty-web"
REPO_NAME="mansion-realty"
IMAGE_NAME="$REGION-docker.pkg.dev/$PROJECT_ID/$REPO_NAME/web"

# ── Environment Variables (simpan di Secret Manager) ──────
GAS_API_URL="https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec"
WA_OFFICE="628123456789"
SITE_URL="https://mansionrealty.co.id"

echo "🚀 Mansion Realty — GCP Deployment"
echo "Project: $PROJECT_ID | Region: $REGION"

# ── 1. Set GCP Project ─────────────────────────────────────
gcloud config set project $PROJECT_ID

# ── 2. Enable APIs ─────────────────────────────────────────
echo "📦 Enabling required GCP APIs..."
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  secretmanager.googleapis.com \
  --quiet

# ── 3. Create Artifact Registry Repository ─────────────────
echo "🗄️  Creating Artifact Registry..."
gcloud artifacts repositories create $REPO_NAME \
  --repository-format=docker \
  --location=$REGION \
  --description="Mansion Realty Docker images" \
  --quiet 2>/dev/null || echo "Repository already exists."

# ── 4. Configure Docker auth ───────────────────────────────
gcloud auth configure-docker $REGION-docker.pkg.dev --quiet

# ── 5. Build & Push image ──────────────────────────────────
echo "🐳 Building Docker image..."
docker build \
  --build-arg NEXT_PUBLIC_GAS_API_URL="$GAS_API_URL" \
  --build-arg NEXT_PUBLIC_WA_OFFICE="$WA_OFFICE" \
  --build-arg NEXT_PUBLIC_COMPANY_NAME="Mansion Realty" \
  --build-arg NEXT_PUBLIC_SITE_URL="$SITE_URL" \
  -t $IMAGE_NAME:latest \
  -t $IMAGE_NAME:$(git rev-parse --short HEAD 2>/dev/null || echo "manual") \
  .

echo "⬆️  Pushing to Artifact Registry..."
docker push $IMAGE_NAME:latest

# ── 6. Store secrets in Secret Manager ─────────────────────
echo "🔐 Storing secrets in Secret Manager..."

store_secret() {
  local name=$1; local value=$2
  echo -n "$value" | gcloud secrets create $name --data-file=- --quiet 2>/dev/null || \
  echo -n "$value" | gcloud secrets versions add $name --data-file=- --quiet
}

# NOTE: Ganti nilai di bawah dengan secret Anda yang sebenarnya
store_secret "mansion-gas-secret"      "your_gas_api_secret_here"
store_secret "mansion-nextauth-secret" "$(openssl rand -base64 32)"

# ── 7. Deploy to Cloud Run ─────────────────────────────────
echo "☁️  Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
  --image=$IMAGE_NAME:latest \
  --region=$REGION \
  --platform=managed \
  --allow-unauthenticated \
  --port=8080 \
  --memory=1Gi \
  --cpu=1 \
  --min-instances=0 \
  --max-instances=10 \
  --concurrency=80 \
  --timeout=60 \
  --set-env-vars="NODE_ENV=production,NEXT_PUBLIC_GAS_API_URL=$GAS_API_URL,NEXT_PUBLIC_WA_OFFICE=$WA_OFFICE,NEXT_PUBLIC_SITE_URL=$SITE_URL" \
  --set-secrets="GAS_API_SECRET=mansion-gas-secret:latest,NEXTAUTH_SECRET=mansion-nextauth-secret:latest" \
  --quiet

# ── 8. Get service URL ─────────────────────────────────────
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format='value(status.url)')
echo ""
echo "✅ Deployment berhasil!"
echo "🌐 Service URL: $SERVICE_URL"
echo ""
echo "📋 Next Steps:"
echo "  1. Set custom domain: gcloud run domain-mappings create --service=$SERVICE_NAME --domain=mansionrealty.co.id --region=$REGION"
echo "  2. Update NEXTAUTH_URL di Secret Manager"
echo "  3. Configure Cloud CDN untuk performa optimal"
echo ""
echo "📊 Monitor:"
echo "  gcloud run services describe $SERVICE_NAME --region=$REGION"
echo "  gcloud logging read 'resource.type=cloud_run_revision' --limit=50"
